let first_Name = "Ronnel";
let last_Name = "Abundo";

const msg = `Hello, ${first_Name} ${last_Name}! how can we help you today?`;

console.log(msg);
